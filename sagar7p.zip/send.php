<?php
$name = $_POST['name'];
$eamil = $_POST['email'];
$message = $_POST['message'];

echo $name;
echo $email;
echo $message;
?>